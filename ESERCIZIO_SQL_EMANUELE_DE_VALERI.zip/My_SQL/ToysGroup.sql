-- Creazione del db toysgroup
CREATE SCHEMA IF NOT EXISTS `toysgroup`;

-- Utilizzo del db
USE `toysgroup`;

-- Creazione tabella 'product'
CREATE TABLE IF NOT EXISTS `toysgroup`.`product` (
  `ID_Product` INT NOT NULL AUTO_INCREMENT,
  `Name_Product` VARCHAR(255) NOT NULL,
  `Name_Category` VARCHAR(255) NOT NULL,
  `List_Price` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`ID_Product`));
  
-- Creazione tabella 'sales'
CREATE TABLE IF NOT EXISTS `toysgroup`.`sales` (
  `ID_Sales` INT NOT NULL AUTO_INCREMENT,
  `ID_Product` INT NOT NULL,
  `ID_State` INT NOT NULL,
  `Price_sales` DECIMAL(10,2),
  `Date_order` DATE NOT NULL,
  PRIMARY KEY (`ID_Sales`),
  FOREIGN KEY (`ID_Product`) 
  REFERENCES `product`(`ID_Product`) 
  ON DELETE CASCADE
  ON UPDATE CASCADE,
  FOREIGN KEY (`ID_State`) 
  REFERENCES `region`(`ID_State`) 
  ON DELETE CASCADE
  ON UPDATE CASCADE);
  
  -- Creazione tabella 'region'
CREATE TABLE IF NOT EXISTS `toysgroup`.`region` (
  `ID_State` INT NOT NULL AUTO_INCREMENT,
  `State` VARCHAR(255) NOT NULL,
  `Città` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`ID_State`));
  
-- Popolazione tabella 'product'
INSERT INTO `toysgroup`.`product`
(`Name_Product`, `Name_Category`, `List_Price`)
VALUES 
('Zoro', 'FunkoPop', '19.99'),
('Luffy', 'FunkoPop', '19.99'),
('Nami', 'FunkoPop', '29.99'),
('Roger', 'ActionFigure', '59.99'),
('Goku', 'ActionFigure', '199.99'),
('Sasuke', 'ActionFigure', '199.99'),
('Pokemon151', 'BoosterBox', '189.99'),
('RomanceDawn', 'BoosterBox', '399.99'),
('TheLordOfTheRings', 'BoosterBox', '399.99'),
('PokemonXY', 'Booster', '9.99'),
('RiseOfTheFloodborn', 'Booster', '9.99'),
('TheFirstChapter', 'Booster', '9.99') -- no sell
;

-- Popolazione tabella 'region'
INSERT INTO `toysgroup`.`region`
(`State`, `Città`)
VALUES 
('Italy', 'Rome'),
('France', 'Parigi'),
('Germany', 'Berlin'),
('Spain', 'Madrid'),
('Denmark', 'Copenaghen') -- no sell
;

-- Popolazione tabella 'sales'
INSERT INTO `toysgroup`.`sales`
(`ID_Product`, `ID_State`, `Price_sales`, `Date_order`)
VALUES 
('1', '1', '19.99', '2022-03-10'),
('1', '1', '19.99', '2022-03-13'),
('3', '2', '29.99', '2022-04-11'),
('4', '3', '59.99', '2022-04-20'),
('4', '2', '59.99', '2022-05-18'),
('2', '4', '19.99', '2022-05-21'),
('5', '4', '199.99', '2022-05-30'),
('6', '3', '199.99', '2022-06-11'),
('7', '1', '189.99', '2022-08-19'),
('7', '3', '189.99', '2022-11-07'),
('8', '2', '399.99', '2022-11-23'),
('8', '2', '399.99', '2022-12-20'),
('9', '3', '399.99', '2023-01-05'),
('10', '4', '9.99', '2023-01-09'),
('11', '3', '9.99', '2023-02-17'),
('6', '2', '199.99', '2023-02-19'),
('7', '3', '189.99', '2023-03-19'),
('7', '1', '189.99', '2023-07-07'),
('1', '3', '19.99', '2023-08-13'),
('3', '2', '29.99', '2023-10-11'),
('4', '3', '59.99', '2023-12-20'),
('8', '2', '399.99', '2023-12-23'),
('8', '2', '399.99', '2024-02-11'),
('2', '4', '19.99', '2024-02-14'),
('5', '4', '199.99', '2024-04-30'),
('6', '3', '199.99', '2024-05-11'),
('7', '1', '189.99', '2024-08-19')
;

/*
1. Verificare che i campi definiti come PK siano univoci.

Si possono verificare in diversi modi uno di questi è seguire il percorso in "Navigator" 
toysgroup > Tables > product > indexes > PRIMARY 
e visualizzare l'output in "information"
 */
 
 SELECT * FROM toysgroup.product;
 SELECT DISTINCT COUNT(ID_Product) FROM product;
 
 SELECT * FROM toysgroup.region;
 SELECT DISTINCT COUNT(ID_State) FROM region;
 
 SELECT * FROM toysgroup.sales;
 SELECT DISTINCT COUNT(ID_Sales) FROM sales;
 
 /*
 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
 */

SELECT YEAR(S.Date_order) anno, SUM(S.Price_sales) totale, (P.Name_Product) prodotti_venduti, COUNT(P.Name_Product) QT
FROM product P JOIN sales S ON P.ID_Product = S.ID_Product
GROUP BY 1,3
ORDER BY 3
;

/*
3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
*/

SELECT YEAR(S.Date_order) Anno, SUM(S.Price_sales) Fatturato, R.State Stato
FROM region R JOIN sales S ON R.ID_State = S.ID_State
GROUP BY 1,3
ORDER BY 1 DESC, 2 DESC
;

/*
4. Q. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
   A. La categoria più richiesta negli ultimi 3 anni è 'BoosterBox' sia per quantità vendute sia per la mole del fatturato.
*/

SELECT P.Name_Category Categoria, SUM(Price_sales) Fatturato, COUNT(Name_Product) QT
FROM product P JOIN sales S ON P.ID_Product = S.ID_Product
GROUP BY 1
ORDER BY 2 DESC
LIMIT 1
;

SELECT P.Name_Category, SUM(S.Price_sales) Fatturato
FROM product P JOIN sales S ON P.ID_Product = S.ID_Product
GROUP BY 1
HAVING Fatturato = 
(SELECT MAX(SUB.Somma) 
FROM (
SELECT P.Name_Category, SUM(S.Price_sales) Somma
FROM product P JOIN sales S ON P.ID_Product = S.ID_Product
GROUP BY 1) SUB)
;

/* 
Q. 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
   
   A. Il prodotto invenduto in qesto caso è sono solo uno, il Booster di 'TFC'. 
   
   1. Analizzerei il singolo prodotto per individuare i motivi per il quale non si è venduto, 
   capire se c'è richiesta e da cosa deriva, se il prodotto ormai è obsoleto, 
   se è stato creato un prodotto migliore.. 
   una volta individuato il problema si può proporre la soluizone 
   vendendo il prodotto attraverso una strategia di marketing.
   
   2. Dato che per quel prodotto c'è poca richiesta o come in questo caso è nulla, 
   si potrebbe vendere in bundle con il prodtto più richiesto, e/o, per i clienti più fedeli si potrebbe aggiungere
   un coupon con "xy" % di sconto, il tutto operando attraverso una strategia di remarketing.
*/

SELECT  P.Name_Product Nome, P.Name_Category Categoria 
FROM Product P 
WHERE P.Name_Product NOT IN
(SELECT DISTINCT P.Name_Product Prodotto 
FROM product P JOIN sales S ON P.ID_Product = S.ID_Product)
;

SELECT P.Name_Product Nome, P.Name_Category Categoria 
FROM product P LEFT JOIN sales S ON P.ID_Product = S.ID_Product
WHERE S.ID_Product IS NULL
;

/* Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente) */

SELECT P.Name_Product Prodotto, MAX(Date_order) Ultima_vendita
FROM Product P JOIN Sales S ON P.ID_Product = S.ID_Product
GROUP BY 1
ORDER BY 2 DESC
;